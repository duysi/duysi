﻿
namespace PhamDuySi_21C1_LTM2.GUI
{
    partial class QuanLyBanDoc
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.Btn_Dong = new System.Windows.Forms.Button();
            this.Btn_Xoa = new System.Windows.Forms.Button();
            this.Dgv_DanhSachBanDoc = new System.Windows.Forms.DataGridView();
            this.Txb_MaLoaiThe = new System.Windows.Forms.TextBox();
            this.Txb_Gioitinh = new System.Windows.Forms.TextBox();
            this.Txb_SDT = new System.Windows.Forms.TextBox();
            this.Txb_Tenbandoc = new System.Windows.Forms.TextBox();
            this.Txb_Diachi = new System.Windows.Forms.TextBox();
            this.Lbl_Maloaithe = new System.Windows.Forms.Label();
            this.Txb_Mathe = new System.Windows.Forms.TextBox();
            this.Lbl_SDT = new System.Windows.Forms.Label();
            this.Lbl_Gioitinh = new System.Windows.Forms.Label();
            this.Lbl_Diachi = new System.Windows.Forms.Label();
            this.Lbl_TenBanDoc = new System.Windows.Forms.Label();
            this.Lbl_Mathe = new System.Windows.Forms.Label();
            this.Q = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.button3 = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.Dgv_DanhSachBanDoc)).BeginInit();
            this.SuspendLayout();
            // 
            // Btn_Dong
            // 
            this.Btn_Dong.Location = new System.Drawing.Point(474, 564);
            this.Btn_Dong.Margin = new System.Windows.Forms.Padding(4);
            this.Btn_Dong.Name = "Btn_Dong";
            this.Btn_Dong.Size = new System.Drawing.Size(99, 38);
            this.Btn_Dong.TabIndex = 18;
            this.Btn_Dong.Text = "ĐÓNG";
            this.Btn_Dong.UseVisualStyleBackColor = true;
            this.Btn_Dong.Click += new System.EventHandler(this.Btn_Dong_Click_1);
            // 
            // Btn_Xoa
            // 
            this.Btn_Xoa.Location = new System.Drawing.Point(318, 564);
            this.Btn_Xoa.Margin = new System.Windows.Forms.Padding(4);
            this.Btn_Xoa.Name = "Btn_Xoa";
            this.Btn_Xoa.Size = new System.Drawing.Size(99, 38);
            this.Btn_Xoa.TabIndex = 19;
            this.Btn_Xoa.Text = "XÓA";
            this.Btn_Xoa.UseVisualStyleBackColor = true;
            this.Btn_Xoa.Click += new System.EventHandler(this.Btn_Xoa_Click);
            // 
            // Dgv_DanhSachBanDoc
            // 
            this.Dgv_DanhSachBanDoc.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.Dgv_DanhSachBanDoc.Location = new System.Drawing.Point(100, 287);
            this.Dgv_DanhSachBanDoc.Margin = new System.Windows.Forms.Padding(4);
            this.Dgv_DanhSachBanDoc.Name = "Dgv_DanhSachBanDoc";
            this.Dgv_DanhSachBanDoc.RowHeadersWidth = 51;
            this.Dgv_DanhSachBanDoc.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.Dgv_DanhSachBanDoc.Size = new System.Drawing.Size(768, 246);
            this.Dgv_DanhSachBanDoc.TabIndex = 17;
            // 
            // Txb_MaLoaiThe
            // 
            this.Txb_MaLoaiThe.Location = new System.Drawing.Point(640, 206);
            this.Txb_MaLoaiThe.Margin = new System.Windows.Forms.Padding(4);
            this.Txb_MaLoaiThe.Name = "Txb_MaLoaiThe";
            this.Txb_MaLoaiThe.Size = new System.Drawing.Size(168, 28);
            this.Txb_MaLoaiThe.TabIndex = 11;
            // 
            // Txb_Gioitinh
            // 
            this.Txb_Gioitinh.Location = new System.Drawing.Point(219, 209);
            this.Txb_Gioitinh.Margin = new System.Windows.Forms.Padding(4);
            this.Txb_Gioitinh.Name = "Txb_Gioitinh";
            this.Txb_Gioitinh.Size = new System.Drawing.Size(189, 28);
            this.Txb_Gioitinh.TabIndex = 12;
            // 
            // Txb_SDT
            // 
            this.Txb_SDT.Location = new System.Drawing.Point(649, 162);
            this.Txb_SDT.Margin = new System.Windows.Forms.Padding(4);
            this.Txb_SDT.Name = "Txb_SDT";
            this.Txb_SDT.Size = new System.Drawing.Size(184, 28);
            this.Txb_SDT.TabIndex = 13;
            // 
            // Txb_Tenbandoc
            // 
            this.Txb_Tenbandoc.Location = new System.Drawing.Point(259, 175);
            this.Txb_Tenbandoc.Margin = new System.Windows.Forms.Padding(4);
            this.Txb_Tenbandoc.Name = "Txb_Tenbandoc";
            this.Txb_Tenbandoc.Size = new System.Drawing.Size(156, 28);
            this.Txb_Tenbandoc.TabIndex = 14;
            // 
            // Txb_Diachi
            // 
            this.Txb_Diachi.Location = new System.Drawing.Point(604, 118);
            this.Txb_Diachi.Margin = new System.Windows.Forms.Padding(4);
            this.Txb_Diachi.Name = "Txb_Diachi";
            this.Txb_Diachi.Size = new System.Drawing.Size(204, 28);
            this.Txb_Diachi.TabIndex = 15;
            // 
            // Lbl_Maloaithe
            // 
            this.Lbl_Maloaithe.AutoSize = true;
            this.Lbl_Maloaithe.Location = new System.Drawing.Point(504, 213);
            this.Lbl_Maloaithe.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.Lbl_Maloaithe.Name = "Lbl_Maloaithe";
            this.Lbl_Maloaithe.Size = new System.Drawing.Size(112, 24);
            this.Lbl_Maloaithe.TabIndex = 4;
            this.Lbl_Maloaithe.Text = "Mã Loại thẻ:";
            // 
            // Txb_Mathe
            // 
            this.Txb_Mathe.Location = new System.Drawing.Point(196, 129);
            this.Txb_Mathe.Margin = new System.Windows.Forms.Padding(4);
            this.Txb_Mathe.Name = "Txb_Mathe";
            this.Txb_Mathe.Size = new System.Drawing.Size(189, 28);
            this.Txb_Mathe.TabIndex = 16;
            // 
            // Lbl_SDT
            // 
            this.Lbl_SDT.AutoSize = true;
            this.Lbl_SDT.Location = new System.Drawing.Point(504, 170);
            this.Lbl_SDT.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.Lbl_SDT.Name = "Lbl_SDT";
            this.Lbl_SDT.Size = new System.Drawing.Size(127, 24);
            this.Lbl_SDT.TabIndex = 5;
            this.Lbl_SDT.Text = "Số Điện thoại:";
            // 
            // Lbl_Gioitinh
            // 
            this.Lbl_Gioitinh.AutoSize = true;
            this.Lbl_Gioitinh.Location = new System.Drawing.Point(109, 217);
            this.Lbl_Gioitinh.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.Lbl_Gioitinh.Name = "Lbl_Gioitinh";
            this.Lbl_Gioitinh.Size = new System.Drawing.Size(91, 24);
            this.Lbl_Gioitinh.TabIndex = 6;
            this.Lbl_Gioitinh.Text = "Giới Tính:";
            // 
            // Lbl_Diachi
            // 
            this.Lbl_Diachi.AutoSize = true;
            this.Lbl_Diachi.Location = new System.Drawing.Point(504, 129);
            this.Lbl_Diachi.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.Lbl_Diachi.Name = "Lbl_Diachi";
            this.Lbl_Diachi.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.Lbl_Diachi.Size = new System.Drawing.Size(72, 24);
            this.Lbl_Diachi.TabIndex = 7;
            this.Lbl_Diachi.Text = "Địa chỉ:";
            // 
            // Lbl_TenBanDoc
            // 
            this.Lbl_TenBanDoc.AutoSize = true;
            this.Lbl_TenBanDoc.Location = new System.Drawing.Point(109, 175);
            this.Lbl_TenBanDoc.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.Lbl_TenBanDoc.Name = "Lbl_TenBanDoc";
            this.Lbl_TenBanDoc.Size = new System.Drawing.Size(126, 24);
            this.Lbl_TenBanDoc.TabIndex = 8;
            this.Lbl_TenBanDoc.Text = "Tên Bạn Đọc:";
            // 
            // Lbl_Mathe
            // 
            this.Lbl_Mathe.AutoSize = true;
            this.Lbl_Mathe.Location = new System.Drawing.Point(109, 133);
            this.Lbl_Mathe.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.Lbl_Mathe.Name = "Lbl_Mathe";
            this.Lbl_Mathe.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.Lbl_Mathe.Size = new System.Drawing.Size(72, 24);
            this.Lbl_Mathe.TabIndex = 9;
            this.Lbl_Mathe.Text = "Mã thẻ:";
            // 
            // Q
            // 
            this.Q.AutoSize = true;
            this.Q.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Q.Location = new System.Drawing.Point(189, 28);
            this.Q.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.Q.Name = "Q";
            this.Q.Size = new System.Drawing.Size(568, 39);
            this.Q.TabIndex = 10;
            this.Q.Text = "QUẢN LÝ DANH SÁCH BẠN ĐỌC";
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(161, 564);
            this.button1.Margin = new System.Windows.Forms.Padding(4);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(99, 38);
            this.button1.TabIndex = 18;
            this.button1.Text = " THÊM";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.Btn_Dong_Click_1);
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(640, 564);
            this.button2.Margin = new System.Windows.Forms.Padding(4);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(99, 38);
            this.button2.TabIndex = 18;
            this.button2.Text = " LƯU";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.Btn_Dong_Click_1);
            // 
            // button3
            // 
            this.button3.Location = new System.Drawing.Point(757, 564);
            this.button3.Margin = new System.Windows.Forms.Padding(4);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(99, 38);
            this.button3.TabIndex = 18;
            this.button3.Text = " LƯU";
            this.button3.UseVisualStyleBackColor = true;
            this.button3.Click += new System.EventHandler(this.Btn_Dong_Click_1);
            // 
            // QuanLyBanDoc
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(10F, 22F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1000, 619);
            this.Controls.Add(this.button3);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.Btn_Dong);
            this.Controls.Add(this.Btn_Xoa);
            this.Controls.Add(this.Dgv_DanhSachBanDoc);
            this.Controls.Add(this.Txb_MaLoaiThe);
            this.Controls.Add(this.Txb_Gioitinh);
            this.Controls.Add(this.Txb_SDT);
            this.Controls.Add(this.Txb_Tenbandoc);
            this.Controls.Add(this.Txb_Diachi);
            this.Controls.Add(this.Lbl_Maloaithe);
            this.Controls.Add(this.Txb_Mathe);
            this.Controls.Add(this.Lbl_SDT);
            this.Controls.Add(this.Lbl_Gioitinh);
            this.Controls.Add(this.Lbl_Diachi);
            this.Controls.Add(this.Lbl_TenBanDoc);
            this.Controls.Add(this.Lbl_Mathe);
            this.Controls.Add(this.Q);
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "QuanLyBanDoc";
            this.Text = "QuanLyBanDoc";
            this.Load += new System.EventHandler(this.QuanLyBanDoc_Load);
            ((System.ComponentModel.ISupportInitialize)(this.Dgv_DanhSachBanDoc)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button Btn_Dong;
        private System.Windows.Forms.Button Btn_Xoa;
        private System.Windows.Forms.DataGridView Dgv_DanhSachBanDoc;
        private System.Windows.Forms.TextBox Txb_MaLoaiThe;
        private System.Windows.Forms.TextBox Txb_Gioitinh;
        private System.Windows.Forms.TextBox Txb_SDT;
        private System.Windows.Forms.TextBox Txb_Tenbandoc;
        private System.Windows.Forms.TextBox Txb_Diachi;
        private System.Windows.Forms.Label Lbl_Maloaithe;
        private System.Windows.Forms.TextBox Txb_Mathe;
        private System.Windows.Forms.Label Lbl_SDT;
        private System.Windows.Forms.Label Lbl_Gioitinh;
        private System.Windows.Forms.Label Lbl_Diachi;
        private System.Windows.Forms.Label Lbl_TenBanDoc;
        private System.Windows.Forms.Label Lbl_Mathe;
        private System.Windows.Forms.Label Q;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button button3;
    }
}