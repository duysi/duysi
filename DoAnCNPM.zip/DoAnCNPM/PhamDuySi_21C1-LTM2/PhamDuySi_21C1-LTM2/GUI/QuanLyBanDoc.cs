﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using PhamDuySi_21C1_LTM2.BLL;
using PhamDuySi_21C1_LTM2.DAL;

namespace PhamDuySi_21C1_LTM2.GUI
{
    public partial class QuanLyBanDoc : Form
    {
        public QuanLyBanDoc()
        {
            InitializeComponent();
        }

        BanDocs bd = new BanDocs();
        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void PrjQuanLyBanDoc_Load(object sender, EventArgs e)
        {
            LoadDataBANDOC();
        }

        void LoadDataBANDOC()
        {
            DataTable tblBanDoc;
            bd = new BanDocs();
            if (bd.Connect())
            {
                tblBanDoc = bd.GetDataBanDoc();
                Dgv_DanhSachBanDoc.DataSource = tblBanDoc;
                BindingDataBANDOC();
            }
            else
                MessageBox.Show("Lỗi kết nối với Database");

        }
        void BindingDataBANDOC()
        {
            Txb_Mathe.DataBindings.Clear();
            Txb_Tenbandoc.DataBindings.Clear();
            Txb_Gioitinh.DataBindings.Clear();
            Txb_Diachi.DataBindings.Clear();
            Txb_SDT.DataBindings.Clear();
            Txb_MaLoaiThe.DataBindings.Clear();

            Txb_Mathe.DataBindings.Add("Text", Dgv_DanhSachBanDoc.DataSource, "MaThe");
            Txb_Tenbandoc.DataBindings.Add("Text", Dgv_DanhSachBanDoc.DataSource, "TenBanDoc");
            Txb_Gioitinh.DataBindings.Add("Text", Dgv_DanhSachBanDoc.DataSource, "GioiTinh");
            Txb_Diachi.DataBindings.Add("Text", Dgv_DanhSachBanDoc.DataSource, "DiaChi");
            Txb_SDT.DataBindings.Add("Text", Dgv_DanhSachBanDoc.DataSource, "SoDT");
            Txb_MaLoaiThe.DataBindings.Add("Text", Dgv_DanhSachBanDoc.DataSource, "MaLT");
        }

        private void Btn_Dong_Click(object sender, EventArgs e)
        {
            DialogResult kq = MessageBox.Show("Bạn có chắc chắn muốn đóng chương trình không?", "Thông báo!", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if (kq == DialogResult.Yes)
            {
                this.Close();
            }
        }
        private int DeleteBanDoc(BanDocs bandoc)
        {
            string SPName = "Usp_DeleteBANDOC";
            string[] parameters = { "@PMaThe" };
            object[] values = { Txb_Mathe.Text };
            return bandoc.BanDocExecuteNonQuery(SPName, parameters, values, true);
        }
        private void Btn_Xoa_Click(object sender, EventArgs e)
        {
            bd = new BanDocs();

            DialogResult kb = MessageBox.Show("Bạn có chắc chắn muốn xóa không?", "Thông báo!", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if (kb == DialogResult.No)
            {
                LoadDataBANDOC();
            }
            else
            {
                if (bd.Connect())
                {
                    int rec = DeleteBanDoc(bd);
                    if (rec > 0)
                    {
                        MessageBox.Show("Đã xóa 1 dòng thànhcông", "Thông báo!");
                        LoadDataBANDOC();
                    }
                    else
                    {
                        MessageBox.Show("Đã xảy ra lỗi trong quátrình xóa dòng dữ liệu", "Thông báo!");
                    }
                }
                else
                {
                    MessageBox.Show("Kết nối với cơ sở dữ liệu thất bại!", "Thông báo");
                }
            }
        }

        private void QuanLyBanDoc_Load(object sender, EventArgs e)
        {
            LoadDataBANDOC();
        }

        private void Btn_Dong_Click_1(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
