﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using PhamDuySi_21C1_LTM2.DAL;
using PhamDuySi_21C1_LTM2.BLL;
namespace PhamDuySi_21C1_LTM2.GUI
{
    public partial class UngDungQuanLy : Form
    {
        public UngDungQuanLy()
        {
            InitializeComponent();
        }

        private void bạnĐọcToolStripMenuItem_Click(object sender, EventArgs e)
        {
            QuanLyBanDoc frm = new QuanLyBanDoc();
            frm.Show();
            this.Hide();
        }

        private void thoátToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
