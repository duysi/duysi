﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using PhamDuySi_21C1_LTM2.BLL;
using PhamDuySi_21C1_LTM2.DAL;
using PhamDuySi_21C1_LTM2.GUI;
namespace PhamDuySi_21C1_LTM2
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Btn_dangnhap_Click(object sender, EventArgs e)
        {
            String ConStr = @"Server=LENOVO\SQLEXPRESS;Database= QuanLySinhVien;Trusted_Connection=True;";
            //Hoặc
            //String ConStr = @"Data Source=.\\SQLEXPRESS; Initial Catalog=QuanLyBanHang; Integrated Security=True;";
            //Khai báo biến đối tượng SqlConnection
            SqlConnection connect = new SqlConnection(ConStr);
            try
            {
                connect.Open();
                MessageBox.Show("Đã kết nối thành công.Mời bạn vào!", "Thông báo !", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            catch (System.Exception)
            {
                MessageBox.Show("Kết nối thất bại!Vui lòng thử lại. ", "Thông báo !", MessageBoxButtons.OKCancel, MessageBoxIcon.Information);
            }
            finally
            {
                connect.Close();
            }
            Users user = new Users();
            if (Txb_Tentaikhoan.TextLength == 0)
            {
                Txb_Matkhau.Focus();
                return;
            }
            if (Txb_Matkhau.TextLength == 0)
            {
                Txb_Matkhau.Focus();
                return;
            }
            if (user.Connect())
            {
                if (user.CheckUser(Txb_Tentaikhoan.Text,
                Txb_Matkhau.Text) > 0)
                {
                    UngDungQuanLy frm = new UngDungQuanLy();
                    frm.Show();
                    this.Hide();
                }
                else
                {
                    MessageBox.Show("Vui lòng kiểm tra lại Tên tài khoản và mật khẩu", "Thông báo",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
            else
            {
                MessageBox.Show("Không kết nối được với CSDL", "Thông báo", MessageBoxButtons.OK,
                MessageBoxIcon.Error);
            }
        }

        private void Btn_Thoat_Click(object sender, EventArgs e)
        {
            DialogResult Kq = MessageBox.Show("Bạn có chắc chắn muốn hủy đăng nhập không ? ", "Thôngbáo", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if (Kq == DialogResult.Yes)
            {
                Application.Exit();
            }
        }

        private void Prj_Login_Load(object sender, EventArgs e)
        {

        }
    }
}
