﻿
namespace PhamDuySi_21C1_LTM2
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.Btn_Thoat = new System.Windows.Forms.Button();
            this.Btn_dangnhap = new System.Windows.Forms.Button();
            this.Txb_Matkhau = new System.Windows.Forms.TextBox();
            this.Txb_Tentaikhoan = new System.Windows.Forms.TextBox();
            this.Lbl_Matkhau = new System.Windows.Forms.Label();
            this.Lbl_Tentaikhoan = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.label1 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // Btn_Thoat
            // 
            this.Btn_Thoat.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Btn_Thoat.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.Btn_Thoat.Location = new System.Drawing.Point(562, 281);
            this.Btn_Thoat.Margin = new System.Windows.Forms.Padding(4);
            this.Btn_Thoat.Name = "Btn_Thoat";
            this.Btn_Thoat.Size = new System.Drawing.Size(128, 41);
            this.Btn_Thoat.TabIndex = 11;
            this.Btn_Thoat.Text = "Thoát";
            this.Btn_Thoat.UseVisualStyleBackColor = true;
            // 
            // Btn_dangnhap
            // 
            this.Btn_dangnhap.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Btn_dangnhap.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.Btn_dangnhap.Location = new System.Drawing.Point(426, 281);
            this.Btn_dangnhap.Margin = new System.Windows.Forms.Padding(4);
            this.Btn_dangnhap.Name = "Btn_dangnhap";
            this.Btn_dangnhap.Size = new System.Drawing.Size(128, 41);
            this.Btn_dangnhap.TabIndex = 12;
            this.Btn_dangnhap.Text = "Đăng nhập";
            this.Btn_dangnhap.UseVisualStyleBackColor = true;
            this.Btn_dangnhap.Click += new System.EventHandler(this.Btn_dangnhap_Click);
            // 
            // Txb_Matkhau
            // 
            this.Txb_Matkhau.Location = new System.Drawing.Point(553, 209);
            this.Txb_Matkhau.Margin = new System.Windows.Forms.Padding(4);
            this.Txb_Matkhau.Name = "Txb_Matkhau";
            this.Txb_Matkhau.PasswordChar = '*';
            this.Txb_Matkhau.Size = new System.Drawing.Size(180, 22);
            this.Txb_Matkhau.TabIndex = 9;
            // 
            // Txb_Tentaikhoan
            // 
            this.Txb_Tentaikhoan.Location = new System.Drawing.Point(553, 174);
            this.Txb_Tentaikhoan.Margin = new System.Windows.Forms.Padding(4);
            this.Txb_Tentaikhoan.Name = "Txb_Tentaikhoan";
            this.Txb_Tentaikhoan.Size = new System.Drawing.Size(180, 22);
            this.Txb_Tentaikhoan.TabIndex = 10;
            // 
            // Lbl_Matkhau
            // 
            this.Lbl_Matkhau.AutoSize = true;
            this.Lbl_Matkhau.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Lbl_Matkhau.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.Lbl_Matkhau.Location = new System.Drawing.Point(422, 218);
            this.Lbl_Matkhau.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.Lbl_Matkhau.Name = "Lbl_Matkhau";
            this.Lbl_Matkhau.Size = new System.Drawing.Size(82, 20);
            this.Lbl_Matkhau.TabIndex = 7;
            this.Lbl_Matkhau.Text = "Mật khẩu:";
            // 
            // Lbl_Tentaikhoan
            // 
            this.Lbl_Tentaikhoan.AutoSize = true;
            this.Lbl_Tentaikhoan.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Lbl_Tentaikhoan.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.Lbl_Tentaikhoan.Location = new System.Drawing.Point(422, 180);
            this.Lbl_Tentaikhoan.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.Lbl_Tentaikhoan.Name = "Lbl_Tentaikhoan";
            this.Lbl_Tentaikhoan.Size = new System.Drawing.Size(114, 20);
            this.Lbl_Tentaikhoan.TabIndex = 8;
            this.Lbl_Tentaikhoan.Text = "Tên tài khoản:";
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::PhamDuySi_21C1_LTM2.Properties.Resources.Login_03;
            this.pictureBox1.Location = new System.Drawing.Point(68, 167);
            this.pictureBox1.Margin = new System.Windows.Forms.Padding(4);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(245, 204);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 6;
            this.pictureBox1.TabStop = false;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.label1.Location = new System.Drawing.Point(161, 80);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(428, 39);
            this.label1.TabIndex = 5;
            this.label1.Text = "ĐĂNG NHẬP HỆ THỐNG";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.LightBlue;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.Btn_Thoat);
            this.Controls.Add(this.Btn_dangnhap);
            this.Controls.Add(this.Txb_Matkhau);
            this.Controls.Add(this.Txb_Tentaikhoan);
            this.Controls.Add(this.Lbl_Matkhau);
            this.Controls.Add(this.Lbl_Tentaikhoan);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.label1);
            this.Name = "Form1";
            this.Text = "Form1";
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button Btn_Thoat;
        private System.Windows.Forms.Button Btn_dangnhap;
        private System.Windows.Forms.TextBox Txb_Matkhau;
        private System.Windows.Forms.TextBox Txb_Tentaikhoan;
        private System.Windows.Forms.Label Lbl_Matkhau;
        private System.Windows.Forms.Label Lbl_Tentaikhoan;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Label label1;
    }
}

