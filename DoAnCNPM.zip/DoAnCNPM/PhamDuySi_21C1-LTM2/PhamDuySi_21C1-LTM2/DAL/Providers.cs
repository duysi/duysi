﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using PhamDuySi_21C1_LTM2.BLL;
namespace PhamDuySi_21C1_LTM2.DAL
{
    class Providers
    {
        public SqlConnection connection;
        public bool connect()
        {
            string connectionStr = ConfigurationManager.ConnectionStrings["connectStr"].ConnectionString.ToString();

            connection = new SqlConnection(connectionStr);
            if ((connection.State == ConnectionState.Closed) || (connection.State == ConnectionState.Broken))
            {
                connection.Open();
                return true;
            }
            else
            {
                return false;
            }
        }
        public void DisConnect()
        {
            connection.Close();
            connection.Dispose();
        }
        public SqlCommand Command(string queryOrSpName, string[] Parameters, object[] Values, bool isStroed)
        {
            SqlCommand cmd = new SqlCommand(queryOrSpName, connection);
            if (isStroed)
            {
                cmd.CommandText = queryOrSpName;
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Connection = connection;
            }
            if (Parameters != null)
            {
                for (int i = 0; i < Parameters.Length; i++)
                {
                    cmd.Parameters.AddWithValue(Parameters[i], Values[i]);
                }
            }
            return cmd;
        }
        public SqlDataReader ExecuteReader(string queryOrName, String[] Parameters, object[] Values, bool isStored)
        {
            SqlDataReader reader = Command(queryOrName, Parameters, Values, isStored).ExecuteReader();
            DisConnect();
            return reader;
        }
        public int BanDocExecuteNonQuery(string queryOrSpName, string[] Parameters, object[] Values, bool isStored)
        {
            int rec = Command(queryOrSpName, Parameters, Values, isStored).ExecuteNonQuery();
            DisConnect();
            return rec;
        }

        public int ExecuteScalar(string queryOrSqname, string[] Parameters, object[] Values)
        {
            int Scalar = (int)Command(queryOrSqname, Parameters, Values, false).ExecuteScalar();
            DisConnect();
            return Scalar;
        }
        public DataTable GetData(string queryOrSpName, string[] Parameters, object[] Values, bool isStored)
        {
            DataTable tbl = new DataTable();
            SqlCommand cmd = Command(queryOrSpName, Parameters, Values, isStored);
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            da.Fill(tbl);
            DisConnect();
            return tbl;
        }
    }
}
