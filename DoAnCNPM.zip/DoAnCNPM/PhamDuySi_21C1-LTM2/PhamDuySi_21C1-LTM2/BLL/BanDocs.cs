﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using PhamDuySi_21C1_LTM2.DAL;
namespace PhamDuySi_21C1_LTM2.BLL
{
    class BanDocs
    {
        Providers providers = new Providers();

        public SqlConnection Connection()
        {
            return providers.connection;
        }
        public Boolean Connect()
        {
            return providers.connect();
        }
        public void DisConnect()
        {
            providers.DisConnect();
        }

        public DataTable GetDataBanDoc()
        {
            string[] parameters = { };
            string[] values = { };
            return providers.GetData("Select * From BanDoc", parameters, values, false);
        }

        public int BanDocExecuteNonQuery(string queryOrSpName, string[] Parameters, object[] Values, bool isStored)
        {
            return providers.BanDocExecuteNonQuery(queryOrSpName, Parameters, Values, isStored);
        }

        public int CheckBanDoc(string MaTheStr)
        {
            string sqlStr = "Select count(*) From BanDoc Where MaThe=@PMaThe";
            string[] parameters = { "@PMaThe" };
            string[] values = { MaTheStr };
            return providers.ExecuteScalar(sqlStr, parameters, values);
        }
    }
}
