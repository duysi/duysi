﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using PhamDuySi_21C1_LTM2.DAL;

namespace PhamDuySi_21C1_LTM2.BLL
{
    class Users
    {
        Providers providers = new Providers();
        public SqlConnection Connection()
        {
            return providers.connection;
        }
        public Boolean Connect()
        {
            return providers.connect();
        }
        public void DisConnect()
        {
            providers.DisConnect();
        }
        
        public int CheckUser(string User, string Pass)
        {
            providers.connect();
            string strsql = "Select count(*) from Users where((TenTK = @TaiKhoan) and(MatKhau = @MatKhauNguoiDung))";
            SqlCommand Cmd = new SqlCommand(strsql, Connection());
            SqlParameter para1 = new
            SqlParameter("@TaiKhoan", User);
            SqlParameter para2 = new
            SqlParameter("@MatKhauNguoiDung", Pass);
            Cmd.Parameters.Add(para1);
            Cmd.Parameters.Add(para2);
            int kqsql = (int)Cmd.ExecuteScalar();
            return kqsql;
        }
    }
}
